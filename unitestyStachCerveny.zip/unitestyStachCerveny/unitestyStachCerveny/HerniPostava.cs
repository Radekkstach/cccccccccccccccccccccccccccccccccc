﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace unitestyStachCerveny
{
    public class HerniPostava
    {
        string Jmeno
        {
            get; set;
        }

        public string jmeno = string.Empty;
        public int level = 0;

        public HerniPostava(string jmeno)
        {
            Jmeno= jmeno;
        }

        public int x
        {
            get; set;
        }
        public int y
        {
            get; set;
        }

        public virtual int  ZmenaPozice(int x, int y)
        {
            return x + y;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
